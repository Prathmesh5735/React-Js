import './App.css'
import 'bootstrap/dist/css/bootstrap.css';
import HeroSection from './components/HeroSection';

function App() {

  return (
    <>
      <HeroSection />
    </>
  )
}

export default App
